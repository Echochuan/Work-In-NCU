//Teacher.java
package exp_code3;

public class Teacher {
    void introduceSelf() {
        System.out.println("我是张老师");
     }
  }
  