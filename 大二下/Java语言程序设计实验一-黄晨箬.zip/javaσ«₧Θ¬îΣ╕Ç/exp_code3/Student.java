//Student.java
package exp_code3;

public class Student {
    void introduceSelf() {
        System.out.println("我是学生，名字是：黄晨箬");
     }
  }
  